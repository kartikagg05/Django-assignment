from django.contrib import admin

from .models import ServiceRequest
admin.site.register(ServiceRequest)

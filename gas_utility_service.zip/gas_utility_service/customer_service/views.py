from django.shortcuts import render, redirect
from .models import ServiceRequest
from .forms import ServiceRequestForm

def create_request(request):
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('request_list')
    else:
        form = ServiceRequestForm()
    return render(request, 'create_request.html', {'form': form})

def request_list(request):
    requests = ServiceRequest.objects.all()
    return render(request, 'request_list.html', {'requests': requests})

from django.http import HttpResponse

def home(request):
    return HttpResponse("<h1>Welcome to the Gas Utility Service App</h1>")
